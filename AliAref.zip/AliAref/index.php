<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>add student</title>
</head>
<body class="container">
  <nav class=" navbar navbar-expand-md navbar-inverse bg-info">
        <ul class="navbar-nav">
          <li class="nav-item">
                <a class="nav-link btn btn-dark mr-1" href="addstudent.php">add student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-dark" href="index.php">all student</a>
            </li>
        </ul>
    </nav>
    <div class="well mt-5">
        <table class="table table-hover">
            <thead>
                <tr>
                    <th>id</th>
                    <th>img</th>
                    <th>name</th>
                    <th>lastname</th>
                    <th>fullname</th>
                    <th>phone</th>
                    <th>edit</th>
                    <th>delete</th>
                </tr>
            </thead>
            <?php
                require('db.php');
                $query=mysqli_query($con,"SELECT * FROM student");
               while ($row=mysqli_fetch_assoc($query)) {

                // img text
            ?>
                <tr>
                    <td>
                        <?php echo $row['id'];?>
                    </td>
                    <td>
                      <img src="upload/<?php echo $row['img']?>" alt="" style="height:50px;  border-radius: 100%">
                    </td>
                    <td>
                        <?php echo $row['name'];?>
                    </td>
                    <td>
                        <?php echo $row['lname'];?>
                    </td>
                    <td>
                        <?php echo $row['name'] . " " .$row['lname'];?>
                    </td>
                    <td>
                        <?php echo $row['phone'];?>
                    </td>
                    <td>
                        <a href="edit.php?id=<?php echo $row['id'];?>" class="btn btn-info">edit</a>
                    </td>
                    <td>
                        <a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-danger">delete</a>
                    </td>
                </tr>
            <?php
               }
            ?>
        </table>
    </div>
</body>
</html>
