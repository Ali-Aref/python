<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css">
    <title>add student</title>
</head>
<body class="container">
  <nav class=" navbar navbar-expand-md navbar-inverse bg-info">
        <ul class="navbar-nav">
          <li class="nav-item">
                <a class="nav-link btn btn-dark mr-1" href="addstudent.php">add student</a>
            </li>
            <li class="nav-item">
                <a class="nav-link btn btn-dark" href="index.php">all student</a>
            </li>
        </ul>
    </nav>
    <div class="row justify-content-center mt-5">
        <div class="col-md-6">
            <form action="add.php" method="post" enctype="multipart/form-data">
                <label for="">student name</label>
                <input type="text" name="name" class="form-control">
                <label for="">student last name</label>
                <input type="text" name="lname" class="form-control">
                <label for="">student phone</label>
                <input type="text" name="phone" class="form-control">
                <label for="">student photo</label>
                <input type="file" name="img" class="form-control">
                <button class="btn btn-success btn-block mt-3 " type="submit" name="submit">sumbit</button>
            </form>
        </div>
    </div>
</body>
</html>
