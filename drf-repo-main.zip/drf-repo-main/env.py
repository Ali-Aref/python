import os
os.environ['CLOUDINARY_URL'] = 'cloudinary://998779825121629:Cixcun3Cr109Ql-XHlRFW4oEBS8@drlmtwmih'
# os.environ['DEV'] = '1'
os.environ['CLIENT_ORIGIN_DEV'] = 'https://8000-zahraraha-drfrepo-fgqhxi88bs3.ws-us97.gitpod.io'
os.environ['SECRET_KEY'] = "zahraSecretKey@drf-repo"
os.environ['DATABASE_URL'] = 'postgres://zpazwrlp:EZpyH2tX1OJt-ULS6lXgxdufEfCt9DpG@trumpet.db.elephantsql.com/zpazwrlp'
os.environ['CLIENT_ORIGIN'] = 'https://3000-zahraraha-reactmarket-ahovh75hfg3.ws-us97.gitpod.io'
