<?php
    if(isset($_POST['update'])){
        $id=$_GET['id'];
        require_once('db.php');
        $name= $_POST['name'];
        $lname= $_POST['lname'];
        $phone= $_POST['phone'];
        $query=mysqli_query($con,"UPDATE  student set name='$name', lname='$lname',phone='$phone' where id='$id'");
        if($query){
            echo "update done";
        }else{
            echo mysqli_error($con);
        }
    }
?>