<?php

        $id=$_GET['id'];
        require_once('db.php');
        $query=mysqli_query($con,"delete  from student  where id='$id'");
        if($query){
            echo "delete done";
        }else{
            echo mysqli_error($con);
        }
    
?>