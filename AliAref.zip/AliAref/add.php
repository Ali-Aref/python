<?php
    if(isset($_POST['submit'])){
        require_once('db.php');
        $name= $_POST['name'];
        $lname= $_POST['lname'];
        $phone= $_POST['phone'];
        $img= $_FILES['img'];
        $imgname=$_FILES['img']['name'];
        $location=$_FILES['img']['tmp_name'];
        $upload=move_uploaded_file($location,'upload/'.$imgname);
        $query=mysqli_query($con,"INSERT INTO student(name, lname, phone, img) values('$name','$lname','$phone','$imgname')");
        if($query){
            echo "data insetered";
        }else{
            echo mysqli_error($con);
        }
    }
?>
