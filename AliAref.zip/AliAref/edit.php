<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.css"> 
    <title>add student</title>
</head>
    <nav class=" navbar navbar-expand-md navbar-inverse bg-dark">
        <ul class="navbar-nav">
            <li class="nav-item"> 
                <a class="nav-link" href="addstudent.php">add student</a>
            </li>
            <li class="nav-item"> 
                <a class="nav-link" href="index.php">all student</a>
            </li> 
        </ul>
    </nav>
<?php
    $id=$_GET['id'];
    require_once('db.php');
    $select="SELECT * FROM student WHERE id='$id'";
    $query=mysqli_query($con,$select);
    while($row=mysqli_fetch_assoc($query)){
        
?>
<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <form action="update.php?id=<?php echo $id?>" method="post" enctype="multipart/form-data">
            <label for="">student name</label>

            <input type="text" name="name" class="form-control" value="<?php echo $row['name'] ;?>">
            <label for="">student last name</label>
            <input type="text" name="lname" class="form-control" value="<?php echo $row['lname'] ;?>">
            <label for="">student phone</label>
            <input type="text" name="phone" class="form-control" value="<?php echo $row['phone'] ;?>">
            <button class="btn btn-info " type="submit" name="update">sumbit</button>
        </form>
    </div>
</div>
<?php
    }

?>
</body>
</html>